
const Usuario = require('../models/usuario');

//--------------------  USUARIO ---------------------------//
const existeUsuarioPorId = async( id ) => {

    // Verificar si el usuario existe
    const existeUsuario = await Usuario.findById(id);
    if ( !existeUsuario ) {
        throw new Error(`El id no existe ${ id }`);
    }
}



module.exports = {
    existeUsuarioPorId,
}

