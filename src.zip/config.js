const config = {
    appconfig:{
        host: process.env.APP_HOST,
        port: process.env.PORT,
    },
}

module.exports  = config